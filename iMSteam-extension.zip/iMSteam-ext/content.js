// ─── Site definitions ────────────────────────────────────────────────────────
const SITES = [
    {
        name: "Online Fix",
        key: "onlinefix",
        url: "https://online-fix.me/",
        iconUrl: "https://i.imgur.com/WAXRAUw.png",
        buildUrl: (base, game) => `${base}index.php?do=search&subaction=search&story=${game}`
    },
    {
        name: "Skidrow",
        key: "skidrow",
        url: "https://www.skidrowreloaded.com/",
        iconUrl: "https://i.imgur.com/qRtlnsn.png",
        buildUrl: (base, game) => `${base}?s=${game}`
    },
    {
        name: "FitGirl",
        key: "fitgirl",
        url: "https://fitgirl-repacks.site/",
        iconUrl: "https://i.imgur.com/GOFbweI.png",
        buildUrl: (base, game) => `${base}?s=${game}`
    },
    {
        name: "SteamRIP",
        key: "steamrip",
        url: "https://steamrip.com/",
        iconUrl: "https://i.imgur.com/tmvOT86.png",
        buildUrl: (base, game) => `${base}?s=${game}`
    },
    {
        name: "Dodi",
        key: "dodi",
        url: "https://dodi-repacks.site/",
        iconUrl: "https://i.imgur.com/g71t1Ge.png",
        buildUrl: (base, game) => `${base}?s=${game}`
    },
    {
        name: "Gload",
        key: "gload",
        url: "https://gload.to/",
        iconUrl: "https://gload.to/logo.png",
        buildUrl: (base, game) => `${base}?s=${game}`
    },
    {
        name: "GOG",
        key: "gog",
        url: "https://www.gog-games.to/",
        iconUrl: "https://i.imgur.com/wXfz72C.png",
        buildUrl: (base, game) => `${base}search/${game}`
    },
    {
        name: "Crack Status",
        key: "crackstatus",
        url: "https://crackrelease.com/",
        iconUrl: "https://crackrelease.com/wp-content/uploads/2025/09/crack-release-icon.png",
        buildUrl: (base, game) => `${base}?s=${game}`
    },
    {
        name: "RuTracker",
        key: "rutracker",
        url: "https://rutracker.org/",
        iconUrl: "https://i.imgur.com/wOjpyEc.png",
        buildUrl: (base, game) => `${base}forum/tracker.php?nm=${game}`
    }
];

// ─── Prefs helpers ────────────────────────────────────────────────────────────
const PREFS_KEY = "iMSteam_enabled";

function getPrefs() {
    try {
        const stored = localStorage.getItem(PREFS_KEY);
        if (stored) return JSON.parse(stored);
    } catch (_) {}
    const defaults = {};
    SITES.forEach(s => { defaults[s.key] = s.key === "onlinefix"; });
    return defaults;
}

function savePrefs(prefs) {
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch (_) {}
}

function isSiteEnabled(key) {
    return getPrefs()[key] === true;
}

// ─── Settings panel ───────────────────────────────────────────────────────────
function openSettings() {
    if (document.getElementById("imsteam-settings-overlay")) return;

    const prefs = getPrefs();

    const overlay = document.createElement("div");
    overlay.id = "imsteam-settings-overlay";
    overlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.7); z-index: 99999;
        display: flex; align-items: center; justify-content: center;
    `;

    const panel = document.createElement("div");
    panel.style.cssText = `
        background: #1a1a2e; border: 1px solid #3a3a5c; border-radius: 12px;
        padding: 24px; min-width: 300px; color: #e0e0e0; font-family: sans-serif;
        box-shadow: 0 8px 32px rgba(0,0,0,0.6);
    `;

    const title = document.createElement("h3");
    title.textContent = "iMSteam — Button Settings";
    title.style.cssText = "margin: 0 0 16px; font-size: 16px; color: #fff; letter-spacing: 0.5px;";
    panel.appendChild(title);

    const desc = document.createElement("p");
    desc.textContent = "Toggle which site buttons appear on game pages.";
    desc.style.cssText = "margin: 0 0 18px; font-size: 12px; color: #888;";
    panel.appendChild(desc);

    const grid = document.createElement("div");
    grid.style.cssText = "display: flex; flex-direction: column; gap: 10px;";

    SITES.forEach(site => {
        const row = document.createElement("label");
        row.style.cssText = `
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 10px; border-radius: 8px; transition: background 0.15s;
        `;
        row.addEventListener("mouseover", () => row.style.background = "rgba(255,255,255,0.05)");
        row.addEventListener("mouseout", () => row.style.background = "transparent");

        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = prefs[site.key] === true;
        cb.style.cssText = "width: 16px; height: 16px; accent-color: #5b8dd9; cursor: pointer;";
        cb.addEventListener("change", () => { prefs[site.key] = cb.checked; });

        const icon = document.createElement("img");
        icon.src = site.iconUrl;
        icon.style.cssText = "width: 24px; height: 24px; border-radius: 4px; object-fit: contain;";

        const label = document.createElement("span");
        label.textContent = site.name;
        label.style.cssText = "font-size: 13px;";

        row.appendChild(cb);
        row.appendChild(icon);
        row.appendChild(label);
        grid.appendChild(row);
    });

    panel.appendChild(grid);

    const btnRow = document.createElement("div");
    btnRow.style.cssText = "display: flex; gap: 10px; margin-top: 20px; justify-content: flex-end;";

    const cancelBtn = document.createElement("button");
    cancelBtn.textContent = "Cancel";
    cancelBtn.style.cssText = `
        padding: 7px 18px; border-radius: 6px; border: 1px solid #555;
        background: transparent; color: #aaa; cursor: pointer; font-size: 13px;
    `;
    cancelBtn.addEventListener("click", () => overlay.remove());

    const saveBtn = document.createElement("button");
    saveBtn.textContent = "Save";
    saveBtn.style.cssText = `
        padding: 7px 18px; border-radius: 6px; border: none;
        background: #5b8dd9; color: #fff; cursor: pointer; font-size: 13px; font-weight: bold;
    `;
    saveBtn.addEventListener("click", () => {
        savePrefs(prefs);
        overlay.remove();
        const existing = document.getElementById('imsteam-btn-group');
        if (existing) existing.remove();
        addGameLinks();
    });

    btnRow.appendChild(cancelBtn);
    btnRow.appendChild(saveBtn);
    panel.appendChild(btnRow);

    overlay.appendChild(panel);
    overlay.addEventListener("click", e => { if (e.target === overlay) overlay.remove(); });
    document.body.appendChild(overlay);
}

// ─── Find the wishlist/follow/ignore button bar ───────────────────────────────
function findQueueBar() {
    return (
        document.querySelector('.queue_actions_ctn') ||
        document.querySelector('.queue_control_buttons') ||
        document.querySelector('.game_area_already_owned') ||
        document.querySelector('.queue_control_button')?.parentElement
    );
}

// ─── Main button injection ────────────────────────────────────────────────────
function addGameLinks() {
    if (!document.querySelector('.apphub_AppName')) return;
    if (document.getElementById('imsteam-btn-group')) return;

    const bar = findQueueBar();
    if (!bar) return;

    const headerElement = document.querySelector('.apphub_AppName');
    const gameName = headerElement.textContent.trim();
    const formattedGameName = encodeURIComponent(
        gameName.toLowerCase()
            .replace(/['_™®©]/g, '')
            .replace(/[^a-zA-Z0-9\s]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
    );

    const enabledSites = SITES.filter(s => isSiteEnabled(s.key));

    const group = document.createElement('div');
    group.id = 'imsteam-btn-group';
    group.style.cssText = 'display: inline-flex; align-items: center; gap: 4px;';

    // Gear button
    const gear = document.createElement('a');
    gear.className = 'btnv6_blue_hoverfade btn_medium';
    gear.title = "iMSteam Settings";
    gear.style.cssText = 'cursor: pointer;';
    const gearSpan = document.createElement('span');
    gearSpan.dataset.tooltipText = "iMSteam Settings";
    gearSpan.textContent = '⚙';
    gearSpan.style.cssText = 'font-size: 15px; display: flex; align-items: center; justify-content: center; width: 18px; height: 18px;';
    gear.appendChild(gearSpan);
    gear.addEventListener('click', e => { e.preventDefault(); openSettings(); });
    group.appendChild(gear);

    // Site icon buttons
    enabledSites.forEach(site => {
        const searchURL = site.buildUrl(site.url, formattedGameName);
        const btn = document.createElement('a');
        btn.className = 'btnv6_blue_hoverfade btn_medium';
        btn.title = site.name;
        btn.style.cssText = 'cursor: pointer;';
        const span = document.createElement('span');
        span.dataset.tooltipText = site.name;
        const icon = document.createElement('img');
        icon.src = site.iconUrl;
        icon.style.cssText = 'width: 26px; height: 26px; object-fit: contain; border-radius: 3px; display: block;';
        span.appendChild(icon);
        btn.appendChild(span);
        btn.addEventListener('click', e => {
            e.preventDefault();
            e.stopPropagation();
            // Open in external browser via Steam protocol
            window.open(searchURL, '_blank');
        });
        group.appendChild(btn);
    });

    bar.appendChild(group);
}

// ─── Bootstrap ────────────────────────────────────────────────────────────────
addGameLinks();

let lastUrl = location.href;
const observer = new MutationObserver((mutations) => {
    if (location.href !== lastUrl) {
        lastUrl = location.href;
        setTimeout(addGameLinks, 500);
    }
    const shouldReinit = mutations.some(mutation =>
        Array.from(mutation.addedNodes).some(node => {
            if (node.nodeType === Node.ELEMENT_NODE) {
                return node.matches?.('.apphub_AppName') ||
                    node.querySelector?.('.apphub_AppName') ||
                    node.matches?.('.queue_control_button') ||
                    node.querySelector?.('.queue_control_button');
            }
            return false;
        })
    );
    if (shouldReinit) setTimeout(addGameLinks, 500);
});
observer.observe(document.body, { childList: true, subtree: true });
setTimeout(addGameLinks, 1000);
